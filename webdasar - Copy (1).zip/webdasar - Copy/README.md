# Petujuk Installasi

1.  Pastikan di komputer sudah terinstall git (download di git-scm)
2.  Pastikan memiliki akun di github.com
3.  Jalankan : git config --globar user.name="nama kalian"
4.  Jalankan : git config --globar user.email emailkalian@blablabla.com
4.  Kemudian yang terakhir jalankan cloning.
5.  menambahkan counter untuk uts